function loginScript(){



  
// Initialize Firebase
var config = {
  apiKey: "AIzaSyDv-r3_401EM-dGNxEzoKfh-1fC-iwhO5k",
  authDomain: "continueone-dev.firebaseapp.com",
  databaseURL: "https://continueone-dev.firebaseio.com",
  projectId: "continueone-dev",
  storageBucket: "continueone-dev.appspot.com",
  messagingSenderId: "620072806800"
};
firebase.initializeApp(config);



}